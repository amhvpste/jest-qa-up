import { render, screen } from '@testing-library/react';

import { Text } from './Text';

describe('Text', () => {
  it('should render provided children', () => {
    const text = 'Hello World';

    render(<Text>{text}</Text>);

    expect(screen.getByText(text)).toBeInTheDocument();
  });

  it('should render with the correct class name', () => {
    const text = 'Hello World';

    render(<Text className="test">{text}</Text>);

    expect(screen.getByText(text)).toBeInTheDocument();
    expect(screen.getByText(text)).toHaveClass('test');
    expect(screen.getByText(text)).toHaveClass('text');
  });

  it('should render with the error class name', () => {
    const text = 'Hello World';

    render(<Text isError>{text}</Text>);

    expect(screen.getByText(text)).toBeInTheDocument();
    expect(screen.getByText(text)).toHaveClass('text');
    expect(screen.getByText(text)).toHaveClass('error');
  });

  it('should render with the success class name', () => {
    const text = 'Hello World';

    render(<Text isSuccess>{text}</Text>);

    expect(screen.getByText(text)).toBeInTheDocument();
    expect(screen.getByText(text)).toHaveClass('text');
    expect(screen.getByText(text)).toHaveClass('success');
  });

  it('should render with the correct class name and error class name', () => {
    const text = 'Hello World';

    render(
      <Text className="test" isError>
        {text}
      </Text>,
    );

    expect(screen.getByText(text)).toBeInTheDocument();
    expect(screen.getByText(text)).toHaveClass('text');
    expect(screen.getByText(text)).toHaveClass('test');
    expect(screen.getByText(text)).toHaveClass('error');
  });
});
